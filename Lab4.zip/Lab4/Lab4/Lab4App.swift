//
//  Lab4App.swift
//  Lab4
//
//  Created by Yash Vipul Naik on 2025-06-06.
//

import SwiftUI

@main
struct Lab4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
