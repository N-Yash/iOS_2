//
//  Week_2_LabApp.swift
//  Week_2_Lab
//
//  Created by Yash Vipul Naik on 2025-05-16.
//

import SwiftUI

@main
struct Week_2_LabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
