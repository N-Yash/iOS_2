//
//  MovieRow.swift
//  movie
//
//  Created by Yash Vipul Naik on 2025-06-17.
//

import SwiftUI

struct MovieRow: View {
    let title: String
    let movies: [Movie]
    let itemWidth: CGFloat
    let itemHeight: CGFloat


    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.headline)
                .padding(.leading)
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 10) {
                    ForEach(movies) { movie in
                        MovieView(movie: movie, width: itemWidth, height: itemHeight)
                            .onTapGesture {
                                // Handle movie selection here (e.g., push to detail view)
                                print("Tapped on: \(movie.title)")
                            }
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}
