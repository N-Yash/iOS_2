//
//  Movie.swift
//  movie
//
//  Created by Yash Vipul Naik on 2025-06-17.
//

import Foundation

struct Movie: Identifiable {
    let id = UUID()
    let title: String
    let imageURL: String // Or a UIImage if you're using local assets
}
