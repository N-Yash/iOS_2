//
//  movieApp.swift
//  movie
//
//  Created by Yash Vipul Naik on 2025-06-17.
//

import SwiftUI

@main
struct movieApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
