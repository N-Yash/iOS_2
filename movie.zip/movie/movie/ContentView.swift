//
//  ContentView.swift
//  movie
//
//  Created by Yash Vipul Naik on 2025-06-17.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HomeView()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
