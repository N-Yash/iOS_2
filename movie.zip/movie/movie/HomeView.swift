//
//  HomeView.swift
//  movie
//
//  Created by Yash Vipul Naik on 2025-06-17.
//

import SwiftUI

struct HomeView: View {
    let categories: [String: [Movie]] = [
        "Trending Now": [
            Movie(title: "Movie 1", imageURL: "https://picsum.photos/200/300"),
            Movie(title: "Movie 2", imageURL: "https://picsum.photos/200/300"),
            Movie(title: "Movie 3", imageURL: "https://picsum.photos/200/300")
        ],
        "Continue Watching": [
            Movie(title: "Movie 4", imageURL: "https://picsum.photos/200/300"),
            Movie(title: "Movie 5", imageURL: "https://picsum.photos/200/300")
        ],
        "My List": [
            Movie(title: "Movie 6", imageURL: "https://picsum.photos/200/300"),
            Movie(title: "Movie 7", imageURL: "https://picsum.photos/200/300"),
            Movie(title: "Movie 8", imageURL: "https://picsum.photos/200/300")
        ]
    ]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 20) {
                ForEach(categories.keys.sorted(), id: \.self) { category in
                    MovieRow(title: category, movies: categories[category]!, itemWidth: 150, itemHeight: 225)
                }
            }
        }
    }
}

