//
//  MovieView.swift
//  movie
//
//  Created by Yash Vipul Naik on 2025-06-17.
//

import SwiftUI

struct MovieView: View {
    let movie: Movie
    let width: CGFloat
    let height: CGFloat

    var body: some View {
        VStack{
            AsyncImage(url: URL(string: movie.imageURL)) { image in
                        image.resizable()
                             .scaledToFill()
                    } placeholder: {
                        Color.gray
                    }
                    .frame(width: width, height: height)
                    .cornerRadius(8)
                    .clipped()
            Text(movie.title)
                .font(.headline)
                .padding(.leading)
        }
    }
}

